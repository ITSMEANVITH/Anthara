package com.eventbooking.controller;

import java.io.File;
import java.io.IOException;

import com.eventbooking.dao.EventDAO;
import com.eventbooking.model.Event;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2,
    maxFileSize = 1024 * 1024 * 10,
    maxRequestSize = 1024 * 1024 * 50
)
@WebServlet("/AddEventServlet")
public class AddEventServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String eventName = request.getParameter("eventName");
        String eventDate = request.getParameter("eventDate");
        String eventTime = request.getParameter("eventTime");
        String venue = request.getParameter("venue");

        double ticketPrice =
                Double.parseDouble(request.getParameter("ticketPrice"));

        int availableSeats =
                Integer.parseInt(request.getParameter("availableSeats"));

        // Upload Image
        Part filePart = request.getPart("eventImage");

        String fileName = filePart.getSubmittedFileName();

        String uploadPath =
                getServletContext().getRealPath("") + "eventImages";

        File uploadDir = new File(uploadPath);

        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }

        filePart.write(uploadPath + File.separator + fileName);

        Event event = new Event();

        event.setEventName(eventName);
        event.setEventDate(eventDate);
        event.setEventTime(eventTime);
        event.setVenue(venue);
        event.setTicketPrice(ticketPrice);
        event.setAvailableSeats(availableSeats);

        // Save only filename in DB
        event.setEventImage(fileName);

        EventDAO dao = new EventDAO();

        if (dao.addEvent(event)) {

            response.sendRedirect("manageEvents.jsp");

        } else {

            response.sendRedirect("addEvent.jsp");

        }

    }

}