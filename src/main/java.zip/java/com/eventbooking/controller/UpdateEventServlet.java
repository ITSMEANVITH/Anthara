package com.eventbooking.controller;

import java.io.IOException;

import com.eventbooking.dao.EventDAO;
import com.eventbooking.model.Event;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/UpdateEventServlet")
public class UpdateEventServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        int eventId = Integer.parseInt(request.getParameter("eventId"));

        String eventName = request.getParameter("eventName");
        String eventDate = request.getParameter("eventDate");
        String eventTime = request.getParameter("eventTime");
        String venue = request.getParameter("venue");

        double ticketPrice =
                Double.parseDouble(request.getParameter("ticketPrice"));

        int availableSeats =
                Integer.parseInt(request.getParameter("availableSeats"));

        Event event = new Event();

        event.setEventId(eventId);
        event.setEventName(eventName);
        event.setEventDate(eventDate);
        event.setEventTime(eventTime);
        event.setVenue(venue);
        event.setTicketPrice(ticketPrice);
        event.setAvailableSeats(availableSeats);

        EventDAO dao = new EventDAO();

        if (dao.updateEvent(event)) {

            response.sendRedirect("manageEvents.jsp");

        } else {

            response.sendRedirect("editEvent.jsp?id=" + eventId);

        }

    }
}