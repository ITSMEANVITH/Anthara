package com.eventbooking.controller;

import java.io.IOException;

import com.eventbooking.dao.BookingDAO;
import com.eventbooking.dao.EventDAO;
import com.eventbooking.model.Booking;
import com.eventbooking.model.Event;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/VerifyTicketServlet")
public class VerifyTicketServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        try {

            int bookingId =
                    Integer.parseInt(request.getParameter("bookingId"));

            BookingDAO bookingDAO =
                    new BookingDAO();

            Booking booking =
                    bookingDAO.getBookingById(bookingId);

            if (booking == null) {

                request.getRequestDispatcher(
                        "invalidTicket.jsp")
                        .forward(request, response);

                return;

            }

            EventDAO eventDAO =
                    new EventDAO();

            Event event =
                    eventDAO.getEventById(
                            booking.getEventId());

            request.setAttribute("booking", booking);

            request.setAttribute("event", event);

            request.getRequestDispatcher(
                    "verifyTicket.jsp")
                    .forward(request, response);

        }

        catch (Exception e) {

            e.printStackTrace();

            request.getRequestDispatcher(
                    "invalidTicket.jsp")
                    .forward(request, response);

        }

    }

}