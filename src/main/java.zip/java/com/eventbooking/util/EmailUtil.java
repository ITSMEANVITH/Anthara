package com.eventbooking.util;

import java.util.Properties;

import jakarta.mail.*;
import jakarta.mail.internet.*;
import jakarta.activation.DataHandler;
import jakarta.mail.util.ByteArrayDataSource;

public class EmailUtil {

    private static final String FROM = "antharaevents@gmail.com";
    private static final String PASSWORD = "trig lhrl vhpz emvf";

    public static void sendEmail(String to,
                                 String subject,
                                 String body) throws Exception {

        Properties props = new Properties();

        props.put("mail.smtp.auth","true");
        props.put("mail.smtp.starttls.enable","true");
        props.put("mail.smtp.host","smtp.gmail.com");
        props.put("mail.smtp.port","587");

        Session session = Session.getInstance(props,
            new Authenticator() {

                protected PasswordAuthentication getPasswordAuthentication() {

                    return new PasswordAuthentication(FROM,PASSWORD);

                }

            });

        Message message = new MimeMessage(session);

        message.setFrom(new InternetAddress(FROM));

        message.setRecipients(
            Message.RecipientType.TO,
            InternetAddress.parse(to));

        message.setSubject(subject);

        message.setContent(body, "text/html");

        Transport.send(message);

    }
    public static void sendEmailWithAttachment(
            String to,
            String subject,
            String body,
            byte[] pdfBytes,
            byte[] calendarBytes) throws Exception {

        Properties props = new Properties();

        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props,
                new Authenticator() {

                    protected PasswordAuthentication getPasswordAuthentication() {

                        return new PasswordAuthentication(FROM, PASSWORD);

                    }

                });

        MimeMessage message = new MimeMessage(session);

        message.setFrom(new InternetAddress(FROM));

        message.setRecipients(
                Message.RecipientType.TO,
                InternetAddress.parse(to));

        message.setSubject(subject);

        MimeBodyPart htmlPart = new MimeBodyPart();

        htmlPart.setContent(body, "text/html");

        MimeBodyPart pdfPart = new MimeBodyPart();

        pdfPart.setFileName("Anthara_Ticket.pdf");

        pdfPart.setDataHandler(

                new DataHandler(

                        new ByteArrayDataSource(

                                pdfBytes,

                                "application/pdf"

                        )

                )

        );

        MimeBodyPart calendarPart = new MimeBodyPart();

        calendarPart.setFileName("Anthara_Event.ics");

        calendarPart.setDataHandler(

                new DataHandler(

                        new ByteArrayDataSource(

                                calendarBytes,

                                "text/calendar"

                        )

                )

        );

        Multipart multipart = new MimeMultipart();

        multipart.addBodyPart(htmlPart);

        multipart.addBodyPart(pdfPart);

        multipart.addBodyPart(calendarPart);

        message.setContent(multipart);

        Transport.send(message);

    }

}